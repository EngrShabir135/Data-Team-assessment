import pandas as pd
import os

csv_filename = "employees.csv"
if not os.path.exists(csv_filename):
    employee_data = """EmployeeID,FirstName,LastName,Department,Salary
1,John,Doe,Sales,50000
2,Jane,Smith,Marketing,55000
3,Alice,Johnson,Sales,48000
4,Bob,Brown,IT,60000
5,Carol,Davis,Marketing,52000"""
    
    with open(csv_filename, "w") as f:
        f.write(employee_data)
    print(f"{csv_filename} created.")

try:
    df = pd.read_csv(csv_filename)

    avg_salary_by_dept = df.groupby("Department")["Salary"].mean().reset_index()
    avg_salary_by_dept.columns = ["Department", "AverageSalary"]

    overall_avg_salary = df["Salary"].mean()

    high_salary_employees = df[df["Salary"] > overall_avg_salary]

    summary_filename = "summary_MuhammadShabir.csv" 
    with open(summary_filename, "w") as f:
        f.write("Average Salary by Department\n")
        avg_salary_by_dept.to_csv(f, index=False)
        f.write("\nEmployees with Salary Above Overall Average\n")
        high_salary_employees.to_csv(f, index=False)

    print(f"Summary saved to {summary_filename}")

except FileNotFoundError:
    print(f"Error: {csv_filename} does not exist.")
except pd.errors.EmptyDataError:
    print("Error: CSV file is empty or not formatted correctly.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
